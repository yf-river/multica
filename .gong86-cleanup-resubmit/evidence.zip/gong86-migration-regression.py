import subprocess,os,secrets,json,time,pathlib
name='gong86-cleanup-regression-'+secrets.token_hex(4);password=secrets.token_hex(20)
env={**os.environ,'POSTGRES_PASSWORD':password}
subprocess.run(['docker','run','-d','--name',name,'--label','purpose=gong86-cleanup-regression','-e','POSTGRES_PASSWORD','-e','POSTGRES_USER=multica','-e','POSTGRES_DB=gong86_cleanup_fixture','-p','127.0.0.1::5432','postgres:17-alpine'],env=env,check=True,capture_output=True)
try:
 info=json.loads(subprocess.check_output(['docker','inspect',name]));port=info[0]['NetworkSettings']['Ports']['5432/tcp'][0]['HostPort']
 env={**os.environ,'DATABASE_URL':f'postgres://multica:{password}@127.0.0.1:{port}/gong86_cleanup_fixture?sslmode=disable'}
 for _ in range(30):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','multica'],capture_output=True).returncode==0:break
  time.sleep(.3)
 with open('gong86-migration.log','w') as f:
  subprocess.run(['go','test','./cmd/migrate','-run','TestEveryConcurrent|TestConcurrentIndexCleanups|TestRunMigrationsRepairsInvalid','-count=1','-v'],cwd='server',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('isolated migration regression passed')
finally:subprocess.run(['docker','rm','-f',name],capture_output=True,check=True)
