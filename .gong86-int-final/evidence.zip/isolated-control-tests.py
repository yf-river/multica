import subprocess,os,secrets,json,time,pathlib
D=pathlib.Path('.integration-recovery-evidence');D.mkdir(exist_ok=True);name='gong86-int-recovery-fixture';password=secrets.token_hex(20)
env={**os.environ,'POSTGRES_PASSWORD':password}
r=subprocess.run(['docker','run','-d','--name',name,'--label','purpose=gong86-integration-control-fixture','-e','POSTGRES_PASSWORD','-e','POSTGRES_USER=multica','-e','POSTGRES_DB=gong86_control_fixture','-p','127.0.0.1::5432','postgres:17-alpine'],env=env,check=True,capture_output=True,text=True)
try:
 info=json.loads(subprocess.check_output(['docker','inspect',name]));port=info[0]['NetworkSettings']['Ports']['5432/tcp'][0]['HostPort'];dsn=f'postgres://multica:{password}@127.0.0.1:{port}/gong86_control_fixture?sslmode=disable'
 env={**os.environ,'DATABASE_URL':dsn,'MULTICA_TEST_DATABASE_URL':dsn}
 (D/'db-handle.json').write_text(json.dumps(dict(container=name,id=r.stdout.strip(),port=port)))
 for _ in range(30):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','multica'],capture_output=True).returncode==0:break
  time.sleep(.3)
 for title,cmd,cwd in [('guard',['python3','scripts/check-test-database.py'],'.'),('migrate',['go','run','./cmd/migrate','up'],'server'),('migration-regression',['go','test','./cmd/migrate','./internal/migrations','-count=1','-v'],'server'),('tests',['go','test','./internal/handler','-run','TestIntegrationOnly|TestRequiredBusiness|TestDelivery|TestPublication','-count=1','-v'],'server')]:
  with open(D/(title+'.log'),'w') as f:subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('isolated control database tests passed')
finally:
 subprocess.run(['docker','rm','-f',name],capture_output=True,check=True)
